<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<ul>
		<li><a href="form.php" target="_blank">input data in csv file</a></li>
		<li><a href="delete.php" target="_blank">Delete data of csv file</li>
	</ul>

</body>
</html>