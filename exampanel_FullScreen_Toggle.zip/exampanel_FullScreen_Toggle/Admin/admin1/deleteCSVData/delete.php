<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Data</title>
</head>
<body>
    <h1>Delete All Student Data</h1>
    <form action="deletedata.php" method="post">
        <input type="hidden" name="delete" value="1">
        <input type="submit" value="Delete All Data">
    </form>
</body>
</html>
