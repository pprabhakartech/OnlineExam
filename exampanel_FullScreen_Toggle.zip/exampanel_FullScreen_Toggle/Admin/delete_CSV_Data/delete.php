<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../styles.css">
    <title>Delete Data</title>
</head>
<body>
	<div class="container">
	    <h1>Delete Exam Record Data</h1>
	    <h3>Form CSV File</h3>
	    <form action="deletedata.php" method="post">
	        <input type="hidden" name="delete" value="1">
	        <input type="submit" value="Delete All Data">
	    </form>
	</div>
</body>
</html>
